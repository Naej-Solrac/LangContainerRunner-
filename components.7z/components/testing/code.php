<?php
    class Code {
        public static function main() {
            $a = 5; // Valor de ejemplo para a
            $b = 3; // Valor de ejemplo para b
            echo "La suma de " . $a . " y " . $b . " es " . ($a + $b) . "\n";
        }
    }
    Code::main();
?>