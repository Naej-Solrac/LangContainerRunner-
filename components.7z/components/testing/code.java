public class code {
    public static void main(String[] args) {
        int a = 5; // Valor de ejemplo para a
        int b = 3; // Valor de ejemplo para b
        System.out.println("La suma de " + a + " y " + b + " es " + (a + b));
    }
}